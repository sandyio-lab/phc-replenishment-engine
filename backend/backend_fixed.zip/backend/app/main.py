"""
PHC Supply Chain Backend — FastAPI Application Entry Point
==========================================================
Start the server:
    uvicorn app.main:app --reload --port 8000

API docs auto-generated at:
    http://localhost:8000/docs   (Swagger UI)
    http://localhost:8000/redoc  (ReDoc)
"""

import os
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

from app.core.database import engine, Base
from app.routes        import phcs, inventory, vendors, orders, analytics

load_dotenv()

# ─────────────────────────────────────────────────────────────────────────────
# Lifespan — runs on startup / shutdown
# ─────────────────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Create all tables on startup (safe if they already exist)
    Base.metadata.create_all(bind=engine)
    yield
    # Nothing to clean up on shutdown for now


# ─────────────────────────────────────────────────────────────────────────────
# App initialisation
# ─────────────────────────────────────────────────────────────────────────────

app = FastAPI(
    title       = "PHC Supply Chain API",
    description = (
        "Backend 1 — Core API & Business Logic for the Autonomous PHC Medicine "
        "Replenishment & Supply Chain Resilience Engine. "
        "Hackathon: Build with AI: Code for Communities (Google Cloud, 2026)."
    ),
    version     = "1.0.0",
    lifespan    = lifespan,
    docs_url    = "/docs",
    redoc_url   = "/redoc",
)

# ─────────────────────────────────────────────────────────────────────────────
# CORS — allow the two frontend apps + local dev
# ─────────────────────────────────────────────────────────────────────────────

_raw_origins = os.getenv("CORS_ORIGINS", "http://localhost:3000,http://localhost:5173")
cors_origins  = [o.strip() for o in _raw_origins.split(",") if o.strip()]

app.add_middleware(
    CORSMiddleware,
    allow_origins     = cors_origins,
    allow_credentials = True,
    allow_methods     = ["*"],
    allow_headers     = ["*"],
)

# ─────────────────────────────────────────────────────────────────────────────
# Routers
# ─────────────────────────────────────────────────────────────────────────────

API_V1 = "/api/v1"

app.include_router(phcs.router,       prefix=API_V1)
app.include_router(inventory.router,  prefix=API_V1)
app.include_router(vendors.router,    prefix=API_V1)
app.include_router(orders.router,     prefix=API_V1)
app.include_router(analytics.router,  prefix=API_V1)

# ─────────────────────────────────────────────────────────────────────────────
# Health check
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/health", tags=["Health"])
def health_check():
    """Liveness probe — returns 200 if the server is running."""
    return {"status": "ok", "service": "phc-backend"}


@app.get("/", tags=["Health"])
def root():
    return {
        "message": "PHC Supply Chain API is running.",
        "docs":    "/docs",
        "version": "1.0.0",
    }
